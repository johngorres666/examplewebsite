/**
 * server.js — Express server for Maison Restaurant
 * Run: npm install && npm start
 * Visit: http://localhost:3000
 */

const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// ─── Middleware ────────────────────────────────────────────────────────────────
// Parse JSON and URL-encoded bodies (for form submissions)
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve all static files (CSS, JS, images) from the /public folder
app.use(express.static(path.join(__dirname, 'public')));

// ─── Routes ───────────────────────────────────────────────────────────────────

// Main page — serves index.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Contact form submission endpoint
app.post('/api/contact', (req, res) => {
  const { name, email, phone, message } = req.body;

  // Basic validation
  if (!name || !email || !message) {
    return res.status(400).json({
      success: false,
      message: 'Name, email, and message are required.'
    });
  }

  // In a real app, you'd send an email or save to a database here.
  console.log('Contact form submission:', { name, email, phone, message });

  res.json({
    success: true,
    message: `Thank you, ${name}! We'll be in touch shortly.`
  });
});

// Reservation form submission endpoint
app.post('/api/reservation', (req, res) => {
  const { name, phone, guests, date, time } = req.body;

  // Basic validation
  if (!name || !phone || !guests || !date || !time) {
    return res.status(400).json({
      success: false,
      message: 'All reservation fields are required.'
    });
  }

  // In a real app, you'd store this in a database or send a confirmation email.
  console.log('Reservation request:', { name, phone, guests, date, time });

  res.json({
    success: true,
    message: `Reservation confirmed for ${name} — ${guests} guest(s) on ${date} at ${time}. We look forward to seeing you!`
  });
});

// Newsletter subscription endpoint
app.post('/api/newsletter', (req, res) => {
  const { email } = req.body;

  if (!email || !email.includes('@')) {
    return res.status(400).json({ success: false, message: 'Please enter a valid email.' });
  }

  console.log('Newsletter subscription:', email);
  res.json({ success: true, message: 'You\'ve been subscribed! Thank you.' });
});

// ─── Start Server ─────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🍽  Maison Restaurant server running at http://localhost:${PORT}\n`);
});
