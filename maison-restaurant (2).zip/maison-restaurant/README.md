# 🍽 Maison — Fine Dining Restaurant Website

A complete, production-ready restaurant website built with HTML, CSS, JavaScript, and Node.js (Express).

---

## 🚀 Quick Start

```bash
# 1. Enter the project folder
cd restaurant

# 2. Install dependencies
npm install

# 3. Start the server
npm start

# 4. Open in your browser
# → http://localhost:3000
```

For development with auto-reload:
```bash
npm run dev   # requires nodemon (installed as devDependency)
```

---

## 📁 Project Structure

```
restaurant/
├── server.js              # Express server + API routes
├── package.json           # Dependencies & scripts
├── README.md              # This file
└── public/
    ├── index.html         # Single-page website
    ├── css/
    │   └── style.css      # All styles
    ├── js/
    │   └── script.js      # All JavaScript
    └── images/            # ← Put your images here
        (empty — add your own photos)
```

---

## 🖼 Adding Your Own Images

Every image section is a clearly labelled placeholder. To replace them:

### Hero Background
In `public/css/style.css`, find `.hero-bg-placeholder` and uncomment:
```css
/* background-image: url('/images/hero.jpg'); */
```
Replace with your image filename.

### Reservation Section Background
Same approach — find `.reservation-bg-placeholder` in `style.css`.

### All Other Images (dishes, gallery, chef, etc.)
Inside `public/index.html`, find any `<div class="img-placeholder ...">` and replace with:
```html
<img src="/images/your-photo.jpg" alt="Description of image" />
```

**Recommended image sizes:**
| Section         | Recommended Size  |
|-----------------|-------------------|
| Hero background | 1920 × 1080px     |
| Featured dishes | 800 × 600px       |
| Menu items      | 640 × 400px       |
| Gallery         | 800 × 800px       |
| Chef portrait   | 600 × 800px       |
| Reviewer photos | 200 × 200px       |

Put all images inside `public/images/` so Express can serve them.

---

## ⚙️ Customising Content

| What to change      | Where                        |
|---------------------|------------------------------|
| Restaurant name     | `index.html` — search "Maison" |
| Address & phone     | `index.html` — Contact section |
| Menu items & prices | `index.html` — Menu section  |
| Brand colours       | `style.css` — `:root` variables |
| Business hours      | `index.html` — Contact & Footer |
| Social media links  | `index.html` — Footer          |
| Google Maps embed   | `index.html` — map-placeholder div |

---

## 🌐 API Endpoints

The Express server exposes three POST endpoints:

| Endpoint           | Purpose              | Required fields                        |
|--------------------|----------------------|----------------------------------------|
| `POST /api/contact`     | Contact form    | `name`, `email`, `message`             |
| `POST /api/reservation` | Table booking   | `name`, `phone`, `guests`, `date`, `time` |
| `POST /api/newsletter`  | Email subscribe | `email`                                |

All return `{ success: boolean, message: string }`.

To actually send emails or save to a database, add your logic inside `server.js` at the marked comments.

---

## 📦 Dependencies

```json
{
  "express": "^4.18.2"       // Web server
}
```

devDependencies:
```json
{
  "nodemon": "^3.0.1"        // Auto-reload during development
}
```

---

## 🎨 Design System

| Token         | Value     | Usage                  |
|---------------|-----------|------------------------|
| `--charcoal`  | `#1a1a1a` | Dark backgrounds       |
| `--ivory`     | `#f5f0e8` | Light text on dark     |
| `--gold`      | `#c9a84c` | Accent, CTAs, prices   |
| `--sage`      | `#7a8c6e` | Tags, subtle accents   |
| `--cream`     | `#faf7f2` | Light section backgrounds |
| Display font  | Playfair Display | Headings        |
| Body font     | Inter     | Body copy              |

---

## ✅ Features Checklist

- [x] Animated loading screen
- [x] Sticky navbar with active section highlighting
- [x] Responsive mobile hamburger menu
- [x] Smooth scroll navigation
- [x] Hero section with CTA buttons
- [x] Featured dishes preview
- [x] About Us with story, mission/vision, chef bio
- [x] Animated stats counter
- [x] Full food menu with 13 items across 4 categories
- [x] Live menu search (debounced)
- [x] Category filter buttons
- [x] Masonry-style gallery with hover effects
- [x] Testimonial slider with auto-advance + swipe
- [x] Contact form with validation + server submission
- [x] Table reservation form with date validation
- [x] Newsletter signup
- [x] Footer with social links, quick links, hours
- [x] Back-to-top button
- [x] Scroll reveal animations
- [x] Fully responsive (desktop → tablet → mobile → small)
- [x] Accessible (focus states, aria labels, reduced motion)
