/**
 * script.js — Maison Fine Dining
 * Features: loader, sticky nav, mobile menu, scroll reveal,
 *           menu filter + search, testimonial slider,
 *           stats counter, form validation, back-to-top
 */

'use strict';

/* ══════════════════════════════════════════════════════════════
   UTILITY HELPERS
══════════════════════════════════════════════════════════════ */
const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

/* ══════════════════════════════════════════════════════════════
   1. LOADING SCREEN
   Hides after page resources are ready (minimum 1.2s for brand feel)
══════════════════════════════════════════════════════════════ */
const initLoader = () => {
  const loader = $('#loader');
  if (!loader) return;

  const hide = () => loader.classList.add('hidden');
  const minDelay = new Promise(res => setTimeout(res, 1400));
  const loaded   = new Promise(res => {
    if (document.readyState === 'complete') res();
    else window.addEventListener('load', res);
  });

  Promise.all([minDelay, loaded]).then(hide);
};


/* ══════════════════════════════════════════════════════════════
   2. STICKY NAVBAR + ACTIVE LINK on SCROLL
══════════════════════════════════════════════════════════════ */
const initNavbar = () => {
  const navbar  = $('#navbar');
  const navLinks = $$('.nav-link');
  const sections = $$('section[id]');

  // Add .scrolled class for styling after first pixel
  const toggleScrolled = () => {
    navbar?.classList.toggle('scrolled', window.scrollY > 10);
  };

  // Highlight the nav link whose section is in view
  const updateActiveLink = () => {
    const scrollY = window.scrollY + 100; // offset for fixed nav height

    sections.forEach(sec => {
      const top    = sec.offsetTop;
      const height = sec.offsetHeight;
      const id     = sec.getAttribute('id');

      if (scrollY >= top && scrollY < top + height) {
        navLinks.forEach(link => {
          link.classList.remove('active');
          if (link.getAttribute('href') === `#${id}`) {
            link.classList.add('active');
          }
        });
      }
    });
  };

  window.addEventListener('scroll', () => {
    toggleScrolled();
    updateActiveLink();
  }, { passive: true });

  toggleScrolled();
  updateActiveLink();
};


/* ══════════════════════════════════════════════════════════════
   3. MOBILE MENU (HAMBURGER TOGGLE)
══════════════════════════════════════════════════════════════ */
const initMobileMenu = () => {
  const hamburger = $('#hamburger');
  const navLinks  = $('#navLinks');

  if (!hamburger || !navLinks) return;

  hamburger.addEventListener('click', () => {
    const isOpen = navLinks.classList.toggle('open');
    hamburger.classList.toggle('open', isOpen);
    hamburger.setAttribute('aria-expanded', String(isOpen));
    document.body.style.overflow = isOpen ? 'hidden' : '';
  });

  // Close menu when a link is clicked
  $$('.nav-link').forEach(link => {
    link.addEventListener('click', () => {
      navLinks.classList.remove('open');
      hamburger.classList.remove('open');
      hamburger.setAttribute('aria-expanded', 'false');
      document.body.style.overflow = '';
    });
  });

  // Close on outside click
  document.addEventListener('click', e => {
    if (!hamburger.contains(e.target) && !navLinks.contains(e.target)) {
      navLinks.classList.remove('open');
      hamburger.classList.remove('open');
      document.body.style.overflow = '';
    }
  });
};


/* ══════════════════════════════════════════════════════════════
   4. SCROLL REVEAL ANIMATIONS
   Uses IntersectionObserver for performance
══════════════════════════════════════════════════════════════ */
const initScrollReveal = () => {
  const els = $$('.reveal, .section-header');

  if (!els.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry, i) => {
      if (entry.isIntersecting) {
        // Stagger children within a grid/row
        const delay = entry.target.dataset.delay || 0;
        setTimeout(() => {
          entry.target.classList.add('revealed');
        }, delay);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

  // Add stagger delays to grid children
  const grids = $$('.featured-grid, .menu-grid, .stats-row, .mission-vision');
  grids.forEach(grid => {
    $$('.reveal, .featured-card, .menu-card, .stat-card, .mv-card', grid)
      .forEach((child, i) => {
        child.dataset.delay = i * 80;
      });
  });

  els.forEach(el => observer.observe(el));
};


/* ══════════════════════════════════════════════════════════════
   5. ANIMATED STATS COUNTER
   Counts up numbers when the stats row scrolls into view
══════════════════════════════════════════════════════════════ */
const initStatsCounter = () => {
  const counters = $$('.stat-number[data-target]');
  if (!counters.length) return;

  const formatNum = n => n >= 1000 ? n.toLocaleString() : String(n);

  const animateCounter = (el, target) => {
    let start = 0;
    const duration = 1800;
    const step = timestamp => {
      if (!start) start = timestamp;
      const progress = Math.min((timestamp - start) / duration, 1);
      // Ease out
      const eased = 1 - Math.pow(1 - progress, 3);
      el.textContent = formatNum(Math.floor(eased * target));
      if (progress < 1) requestAnimationFrame(step);
      else el.textContent = formatNum(target);
    };
    requestAnimationFrame(step);
  };

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const target = parseInt(entry.target.dataset.target, 10);
        animateCounter(entry.target, target);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.5 });

  counters.forEach(el => observer.observe(el));
};


/* ══════════════════════════════════════════════════════════════
   6. MENU FILTERING + SEARCH
══════════════════════════════════════════════════════════════ */
const initMenu = () => {
  const filterBtns = $$('.filter-btn');
  const menuCards  = $$('.menu-card');
  const searchInput = $('#menuSearch');
  const noResults  = $('#noResults');

  let activeCategory = 'all';
  let searchQuery    = '';

  const filterCards = () => {
    let visibleCount = 0;

    menuCards.forEach(card => {
      const category = card.dataset.category;
      const name     = card.dataset.name.toLowerCase();

      const matchesCategory = activeCategory === 'all' || category === activeCategory;
      const matchesSearch   = name.includes(searchQuery) ||
                              card.querySelector('p')?.textContent.toLowerCase().includes(searchQuery);

      const visible = matchesCategory && matchesSearch;
      card.classList.toggle('hidden', !visible);
      if (visible) visibleCount++;
    });

    if (noResults) noResults.style.display = visibleCount === 0 ? 'block' : 'none';
  };

  // Category buttons
  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      activeCategory = btn.dataset.category;
      filterCards();
    });
  });

  // Search input (debounced)
  let searchTimer;
  searchInput?.addEventListener('input', e => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => {
      searchQuery = e.target.value.toLowerCase().trim();
      filterCards();
    }, 250);
  });
};


/* ══════════════════════════════════════════════════════════════
   7. TESTIMONIAL SLIDER
══════════════════════════════════════════════════════════════ */
const initTestimonialSlider = () => {
  const slides    = $$('.testimonial-slide');
  const dotsWrap  = $('#sliderDots');
  const prevBtn   = $('#prevBtn');
  const nextBtn   = $('#nextBtn');

  if (!slides.length || !dotsWrap) return;

  let current   = 0;
  let autoTimer = null;

  // Build dot indicators
  slides.forEach((_, i) => {
    const dot = document.createElement('button');
    dot.className = `dot${i === 0 ? ' active' : ''}`;
    dot.setAttribute('aria-label', `Review ${i + 1}`);
    dot.addEventListener('click', () => goTo(i));
    dotsWrap.appendChild(dot);
  });

  const dots = $$('.dot', dotsWrap);

  const goTo = (index) => {
    slides[current].classList.remove('active');
    dots[current].classList.remove('active');
    current = (index + slides.length) % slides.length;
    slides[current].classList.add('active');
    dots[current].classList.add('active');
  };

  prevBtn?.addEventListener('click', () => { goTo(current - 1); resetAuto(); });
  nextBtn?.addEventListener('click', () => { goTo(current + 1); resetAuto(); });

  // Auto-advance every 5 seconds
  const startAuto = () => {
    autoTimer = setInterval(() => goTo(current + 1), 5000);
  };
  const resetAuto = () => {
    clearInterval(autoTimer);
    startAuto();
  };

  startAuto();

  // Pause on hover
  const slider = $('#testimonialSlider');
  slider?.addEventListener('mouseenter', () => clearInterval(autoTimer));
  slider?.addEventListener('mouseleave', startAuto);

  // Swipe support on mobile
  let startX = 0;
  slider?.addEventListener('touchstart', e => { startX = e.touches[0].clientX; }, { passive: true });
  slider?.addEventListener('touchend', e => {
    const diff = startX - e.changedTouches[0].clientX;
    if (Math.abs(diff) > 50) {
      diff > 0 ? goTo(current + 1) : goTo(current - 1);
      resetAuto();
    }
  });
};


/* ══════════════════════════════════════════════════════════════
   8. FORM VALIDATION & SUBMISSION (Contact)
══════════════════════════════════════════════════════════════ */
const initContactForm = () => {
  const form    = $('#contactForm');
  if (!form) return;

  const nameInput  = $('#contactName');
  const emailInput = $('#contactEmail');
  const msgInput   = $('#contactMessage');
  const nameErr    = $('#nameError');
  const emailErr   = $('#emailError');
  const msgErr     = $('#msgError');
  const successEl  = $('#contactSuccess');
  const submitBtn  = $('#contactSubmit');

  const showError = (el, msg) => { if (el) el.textContent = msg; };
  const clearError = el => { if (el) el.textContent = ''; };

  const validateEmail = email => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

  const validate = () => {
    let valid = true;

    clearError(nameErr); clearError(emailErr); clearError(msgErr);

    if (!nameInput?.value.trim()) {
      showError(nameErr, 'Please enter your name.');
      valid = false;
    }
    if (!validateEmail(emailInput?.value || '')) {
      showError(emailErr, 'Please enter a valid email address.');
      valid = false;
    }
    if (!msgInput?.value.trim()) {
      showError(msgErr, 'Please enter a message.');
      valid = false;
    }
    return valid;
  };

  form.addEventListener('submit', async e => {
    e.preventDefault();
    if (!validate()) return;

    // Loading state
    submitBtn.disabled = true;
    submitBtn.querySelector('span').textContent = 'Sending…';

    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name:    nameInput.value.trim(),
          email:   emailInput.value.trim(),
          phone:   $('#contactPhone')?.value.trim(),
          message: msgInput.value.trim()
        })
      });
      const data = await res.json();

      if (data.success) {
        successEl.textContent = data.message;
        form.reset();
      } else {
        successEl.textContent = data.message || 'Something went wrong. Please try again.';
      }
    } catch {
      successEl.textContent = 'Unable to send. Please call or email us directly.';
    } finally {
      submitBtn.disabled = false;
      submitBtn.querySelector('span').textContent = 'Send Message';
    }
  });
};


/* ══════════════════════════════════════════════════════════════
   9. RESERVATION FORM
══════════════════════════════════════════════════════════════ */
const initReservationForm = () => {
  const form      = $('#reservationForm');
  if (!form) return;

  const successEl = $('#resSuccess');
  const submitBtn = $('#resSubmit');

  // Set minimum date to today
  const dateInput = $('#resDate');
  if (dateInput) {
    const today = new Date().toISOString().split('T')[0];
    dateInput.min = today;
  }

  form.addEventListener('submit', async e => {
    e.preventDefault();

    const name   = $('#resName')?.value.trim();
    const phone  = $('#resPhone')?.value.trim();
    const guests = $('#resGuests')?.value;
    const date   = $('#resDate')?.value;
    const time   = $('#resTime')?.value;

    if (!name || !phone || !guests || !date || !time) {
      successEl.textContent = 'Please fill in all fields.';
      successEl.style.color = '#e07070';
      return;
    }

    submitBtn.disabled = true;
    submitBtn.querySelector('span').textContent = 'Confirming…';
    successEl.style.color = '';

    try {
      const res = await fetch('/api/reservation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, phone, guests, date, time })
      });
      const data = await res.json();

      successEl.textContent = data.message;
      if (data.success) form.reset();
    } catch {
      successEl.textContent = 'Unable to process. Please call us to reserve.';
    } finally {
      submitBtn.disabled = false;
      submitBtn.querySelector('span').textContent = 'Confirm Reservation';
    }
  });
};


/* ══════════════════════════════════════════════════════════════
   10. NEWSLETTER FORM
══════════════════════════════════════════════════════════════ */
const initNewsletter = () => {
  const form    = $('#newsletterForm');
  const msgEl   = $('#newsletterMsg');
  if (!form) return;

  form.addEventListener('submit', async e => {
    e.preventDefault();
    const email = $('#newsletterEmail')?.value.trim();

    if (!email || !email.includes('@')) {
      if (msgEl) { msgEl.textContent = 'Please enter a valid email.'; msgEl.style.color = '#e07070'; }
      return;
    }

    try {
      const res  = await fetch('/api/newsletter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });
      const data = await res.json();
      if (msgEl) {
        msgEl.textContent  = data.message;
        msgEl.style.color  = '';
      }
      if (data.success) form.reset();
    } catch {
      if (msgEl) { msgEl.textContent = 'Something went wrong. Try again later.'; msgEl.style.color = '#e07070'; }
    }
  });
};


/* ══════════════════════════════════════════════════════════════
   11. BACK TO TOP BUTTON
══════════════════════════════════════════════════════════════ */
const initBackToTop = () => {
  const btn = $('#backToTop');
  if (!btn) return;

  window.addEventListener('scroll', () => {
    btn.classList.toggle('visible', window.scrollY > 500);
  }, { passive: true });

  btn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
};


/* ══════════════════════════════════════════════════════════════
   12. DYNAMIC FOOTER YEAR
══════════════════════════════════════════════════════════════ */
const initYear = () => {
  const el = $('#currentYear');
  if (el) el.textContent = new Date().getFullYear();
};


/* ══════════════════════════════════════════════════════════════
   13. SMOOTH SCROLLING for nav anchor links
   (CSS scroll-behavior:smooth handles most cases, but this
    provides an offset for the fixed navbar)
══════════════════════════════════════════════════════════════ */
const initSmoothScroll = () => {
  $$('a[href^="#"]').forEach(link => {
    link.addEventListener('click', e => {
      const target = document.querySelector(link.getAttribute('href'));
      if (!target) return;
      e.preventDefault();
      const navH = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--nav-h'), 10) || 72;
      const top  = target.getBoundingClientRect().top + window.scrollY - navH;
      window.scrollTo({ top, behavior: 'smooth' });
    });
  });
};


/* ══════════════════════════════════════════════════════════════
   INIT — Run everything when DOM is ready
══════════════════════════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', () => {
  initLoader();
  initNavbar();
  initMobileMenu();
  initScrollReveal();
  initStatsCounter();
  initMenu();
  initTestimonialSlider();
  initContactForm();
  initReservationForm();
  initNewsletter();
  initBackToTop();
  initYear();
  initSmoothScroll();
});
